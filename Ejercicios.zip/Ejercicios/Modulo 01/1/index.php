<?php
$nombre = "Jhon";
$especialidad = "Desarrollo Web";
$edad=19;
$ciudad= "San Marttin,Pangoa";
$mensaje="Bienvenido a mi perfil, soy un desarrollador web apasionado ven conocer más sobre mis proyectos y habilidades!";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi pagina </title>
    <link rel="stylesheet" href="1.css">
</head>
<body>
<div class="container">
    <div class="bloque">
        <h1><?php echo $nombre; ?></h1>
        <p>Especialidad: <?php echo $especialidad; ?></p>
        <p>Edad: <?php echo $edad; ?> años</p>
        <p>Ciudad: <?php echo $ciudad; ?></p>
        <p><?php echo $mensaje; ?></p>
    </div>
</div>
</body>
</html>