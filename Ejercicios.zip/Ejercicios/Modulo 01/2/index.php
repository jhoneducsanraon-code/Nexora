<?php

$curso = "ingenieria en software";
$duracion = "3 años";
$nivel = "superior";
$profe = "Gunar castro";

if ($duracion == "3 años") {
    $estado = "activo";
} else {
    $estado = "inactivo";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Curso</title>
    <link rel="stylesheet" href="2.css">
</head>
<body>
<div class="container">
    <div class="card">
        <div class="info">
            <h2>Curso: <?php echo $curso; ?></h2>
            <p>Duración: <?php echo $duracion; ?></p>
            <p>Nivel: <?php echo $nivel; ?></p>
            <p>Profesor: <?php echo $profe; ?></p>
        </div>
        <div class="estado">
            <p>Estado:</p>
            <span>
                <?php echo $estado; ?>
            </span>
        </div>
    </div>
</div>
</body>
</html>