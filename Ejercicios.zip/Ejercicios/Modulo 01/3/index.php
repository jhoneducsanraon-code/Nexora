<?php
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $carrera = $_POST["carrera"];

    $mensaje = "Gracias $nombre. Te registraste en la carrera de $carrera.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="3.css">
</head>
<body>

<div class="formulario">

    <h2>Registro SENATI Río Negro</h2>

    <?php if($mensaje != ""){ ?>
        <div class="mensaje">
            <?php echo $mensaje; ?>
        </div>
    <?php } ?>

    <form method="POST">

        <label>Nombre</label>
        <input type="text" name="nombre" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Carrera</label>
        <select name="carrera">

            <option>Mecánica Automotriz</option>
            <option>Ingeniería de Software</option>
            <option>Electricidad Industrial</option>
            <option>Administración Industrial</option>
            <option>Diseño Gráfico</option>
            <option>Mecatrónica</option>

        </select>

        <button type="submit">Registrar</button>

    </form>

</div>

</body>
</html>