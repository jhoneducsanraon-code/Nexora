<?php
$estado = "inactivo";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>estado</title>
    <link rel="stylesheet" href="4.css">
</head>
<body>
<?php
    if ($estado == "activo") {
echo "<h1 style='color:green;'>activo</h1>";
} else {
echo "<h1 style='color:red;'>inactivo</h1>"; 
} 
?>
</body>
</html>