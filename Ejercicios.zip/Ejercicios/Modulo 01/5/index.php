<?php

$mensaje = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $nombre = $_POST["nombre"];

    if($nombre != ""){
        $mensaje = "Gracias $nombre por interesarte en nuestro producto digital.";
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="5.css">
    <title>Landing Page</title>
    
</head>
<body>

<div class="landing">

    <?php if($mensaje != ""){ ?>
        <div class="mensaje">
            <?php echo $mensaje; ?>
        </div>
    <?php } ?>

    <h1>Curso de Diseño Web</h1>

    <h3>Aprende HTML, CSS y PHP desde cero</h3>

    <div class="precio">
        S/ 99
    </div>

    <ul>
        <li>Clases prácticas</li>
        <li>Acceso de por vida</li>
        <li>Certificado digital</li>
    </ul>

    <form method="POST">

        <input type="text" name="nombre" placeholder="Ingresa tu nombre">

        <button type="submit">
            Comprar Ahora
        </button>

    </form>

</div>

</body>
</html>