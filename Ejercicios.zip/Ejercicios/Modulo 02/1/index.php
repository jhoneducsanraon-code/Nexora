<?php
$productos = [
    [
        "Nombre" => "Licuadora",
        "Precio" => "69",
        "stock"  => "10",
    ],
    [
        "Nombre" => "Refrigeradora",
        "Precio" => "899",
        "stock"  => "5",
    ],
    [
        "Nombre" => "Microondas",
        "Precio" => "199",
        "stock"  => "8",
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="2,1.css">
    <title>Tiendita</title>
</head>
<body>
    <div class="contenedor">
        <?php foreach($productos as $producto){ ?>
           <div class="tarjeta">
                <h2>
                    <?php echo $producto["Nombre"]; ?>
                </h2>
                <P>
                    Precio: S/ <?php echo $producto["Precio"]; ?>
                </P>
                <p>
                    Stock: <?php echo $producto["stock"]; ?>
                </p>   
           </div>
       <?php } ?>  
    </div>
</body>
</html>