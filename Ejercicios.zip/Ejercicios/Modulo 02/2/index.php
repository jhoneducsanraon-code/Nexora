<?php 
$nombre="";
$edad= "";
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $nombre = $_POST["nombre"];
    $edad = $_POST["edad"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="2,2.css">  
    <title>Login</title>
</head>
<body>
    <div class="contenedor">
    <h2>Registro</h2>
    <form method="POST">
        <label>Nombre</label>
        <input type="text" name="nombre" required>
        <label>Edad</label>
        <input type="number" name="edad" required>
        <button type="submit">
            Registrar
        </button>
    </form>
    <?php if($nombre != "" && $edad != ""){ ?>
        <div class="datos">
            <h3>Datos Registrados</h3>
            <p>
                <strong>Nombre:</strong>
                <?php echo $nombre; ?>
            </p>
            <p>
                <strong>Edad:</strong>
                <?php echo $edad; ?>
            </p>
        </div>
    <?php } ?>
</div>
</body>
</html>