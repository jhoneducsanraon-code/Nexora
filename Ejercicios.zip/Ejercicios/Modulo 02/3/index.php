<?php

$total = "";
$mensaje = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $producto1 = $_POST["producto1"];
    $producto2 = $_POST["producto2"];
    $producto3 = $_POST["producto3"];
    if($producto1 != "" && $producto2 != "" && $producto3 != ""){
        $total = $producto1 + $producto2 + $producto3;
        $mensaje = "El total de tu pedido es: S/ " . $total;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Pedidos</title>
    <link rel="stylesheet" href="2,3.css"> 
</head>
<body>
<div class="contenedor">
    <h2>Pedidos</h2>
    <form method="POST">
        <label>Producto 1</label>
        <input type="number" name="producto1" placeholder="Precio">
        <label>Producto 2</label>
        <input type="number" name="producto2" placeholder="Precio">
        <label>Producto 3</label>
        <input type="number" name="producto3" placeholder="Precio">
        <button type="submit">
            Calcular Total
        </button>
    </form>
    <?php if($mensaje != ""){ ?>
        <div class="mensaje">
            <?php echo $mensaje; ?>
        </div>
    <?php } ?>
</div>
</body>
</html>