<?php
$empleados = [
    ['nombre' => 'Juan Pérez', 'cargo' => 'Gerente General', 'salario' => 850],
    ['nombre' => 'María Gómez', 'cargo' => 'Desarrollador Senior', 'salario' => 650],
    ['nombre' => 'Sofía Torres', 'cargo' => 'Contadora', 'salario' => 420]
];

$total_salarios = 0;
foreach($empleados as $emp) {
    $total_salarios += $emp['salario'];
}
$mensaje = "Total empleados: " . count($empleados) . " | Presupuesto mensual: S/ " . number_format($total_salarios, 0, ',', '.');
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabla de Empleados</title>
    <link rel="stylesheet" href="2,4.css">
</head>
<body>
<div class="contenedor">
    <h2>Empleados</h2>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Cargo</th>
                <th>Salario</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($empleados as $empleado): ?>
            <tr>
                <td><?= $empleado['nombre'] ?></td>
                <td><?= $empleado['cargo'] ?></td>
                <td>S/ <?= number_format($empleado['salario'], 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if($mensaje != ""){ ?>
        <div class="mensaje">
            <?= $mensaje ?>
        </div>
    <?php } ?>
</div>
</body>
</html>