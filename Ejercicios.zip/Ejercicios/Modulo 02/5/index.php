<?php
$visitas = rand(1200, 2500);
$ventas = rand(150, 400);
$clientes = rand(80, 150);
$total = $visitas + $ventas + $clientes;
$mensaje = "Resumen del día: Visitas $visitas | Ventas $ventas | Clientes $clientes | Total $total";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="2,5.css">
</head>
<body>
<div class="contenedor">
    <h2>Dashboard</h2>
    
    <div class="metricas">
        <div class="metrica">
            <label>Visitas</label>
            <input type="text" value="<?= $visitas ?>" readonly>
        </div>
        <div class="metrica">
            <label>Ventas</label>
            <input type="text" value="<?= $ventas ?>" readonly>
        </div>
        <div class="metrica">
            <label>Clientes</label>
            <input type="text" value="<?= $clientes ?>" readonly>
        </div>
    </div>
    <?php if($mensaje != ""){ ?>
        <div class="mensaje">
            <?= $mensaje ?>
        </div>
    <?php } ?>
</div>
</body>
</html>