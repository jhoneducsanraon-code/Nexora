<?php
$resultado="";
if($_POST){
    $n1=$_POST['n1'];
    $n2=$_POST['n2'];
    $op=$_POST['op'];
    if($op=='+') $resultado=$n1+$n2;
    if($op=='-') $resultado=$n1-$n2;
    if($op=='*') $resultado=$n1*$n2;
    if($op=='/') $resultado=($n2!=0)?$n1/$n2:"Error";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <<link rel="stylesheet" href="3,1.css">
    <title>Calculadora</title>
</head>
<body>
    <div class="form">
        <h2> Calculadora</h2>
        <form method=post>
            <input type=number name=n1 placeholder="Número 1" value="<?= $_POST['n1']??'' ?>">
            <input type=number name=n2 placeholder="Número 2" value="<?= $_POST['n2']??'' ?>">
            <select name=op>
                <option value="+" <?= ($_POST['op']??'+')=='+'?'selected':'' ?>>Sumar</option>
                <option value="-">Restar</option>
                <option value="*">Multiplicar</option>
                <option value="/">Dividir</option>
            </select>
            <button>Calcular</button>
        </form>
        <?php if($resultado!=""): ?>
            <div style="background:#d4edda;color:#155724;padding:20px;border-radius:10px;text-align:center;font-weight:bold;">
            Resultado: <?= $resultado ?>
            </div>
            <?php endif ?>
 </div>
</body>
</html>