<?php
$Neto ="";
if($_POST){
    $salrio=$_POST["salario"];
    if($salrio >= "15000") $IMPUESTO=0;
    elseif($salrio >= "17000") $IMPUESTO=($salrio-415)*0.08;
    elseif($salrio >= "20000") $IMPUESTO=($salrio-621)*0.14;
    else $IMPUESTO=($salrio-12000)*0.17+5850;
    $Neto=$salrio-$IMPUESTO;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="3,2.css">
    <title>Inpuesto salario</title>
</head>
<body>
<div class="form">
    <form method="post">
        <input type="number" name="salario" placeholder="Salario Anual"value="<?= $_POST['salario']??'' ?>">
        <button>Calcular</button>
    </form>
    <?php if($Neto !=""){ ?>
    <div>
        salario:s/<?= number_format($_POST["salario"]) ?><br>
       <strong> Neto:/ <?= number_format($Neto) ?></strong>
    </div>
    <?php } ?>
</div>
</body>
</html>