<?php
$neto="";
$impuesto=0;
$salario="";
if($_POST){
    $salario=$_POST['salario'];
    if($salario<=41500){
        $impuesto=0;
    }elseif($salario<=62100){
        $impuesto=($salario-41500)*0.08;
    }elseif($salario<=88500){
        $impuesto=1650+($salario-62100)*0.14;
    }else{
        $impuesto=($salario-88500)*0.17+5850;
    }
    $neto=$salario-$impuesto;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Impuestos</title>
<link rel="stylesheet" href="3,3.css">
</head>
<body>
    <div class="form">
    <h2>Impuestos</h2>
        <form method="post">
            <input
            type="number"
            name="salario"
            placeholder="Salario anual"
            value="<?= $_POST['salario'] ?? '' ?>"
            required
            >
            <button type="submit">
            Calcular
            </button>
        </form>
    <?php if($neto!=""): ?>
    <div class="resultado">
        Salario: S/ <?= number_format($salario,2) ?><br>
        Impuesto: S/ <?= number_format($impuesto,2) ?><br>
            <strong>
            Neto: S/ <?= number_format($neto,2) ?>
            </strong>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>