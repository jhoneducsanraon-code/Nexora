<?php
$mensaje="";
if($_POST){
    if($_POST['user']=='admin' && $_POST['pass']=='123'){
        $mensaje="incio de sesión correcta";
    }else{
        $mensaje="usuario o contraseña incorrecta";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="3,4.css">
<title>Login</title>

</head>
<body>
    <div class="form">
    <h2>Login</h2>
    <form method="post">
    <input type="text" name="user" placeholder="Usuario"value="<?= $_POST['user'] ?? '' ?>">
    <input type="password" name="pass" placeholder="Contraseña">
     <button type="submit">Ingresar</button>
   </form>
    <?php if($mensaje): ?>
    <div class="<?= $mensaje=='incio de sesión correcta' ? 'ok' : 'error' ?>">
        <?= $mensaje ?>
    </div>
        <?php endif; ?>
    </div>

</body>
</html>