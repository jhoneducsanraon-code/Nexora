<?php
$mesaje = "";
$tipo = "";
if($_POST){
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $contrae = $_POST["password"];
    $edad = $_POST["edad"];
    if(
        empty($nombre) ||
        empty($email) ||
        empty($contrae) ||
        empty($edad)
    ){
        $mesaje = "Todos los campos son obligatorios";
        $tipo = "error";
    }
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $mesaje = "Correo invalido";
        $tipo = "error";
    }
    elseif($edad < 18){
        $mesaje = "Debe ser mayor de edad";
        $tipo = "error";
    }
    elseif(strlen($contrae) < 8){
        $mesaje = "La contraseña debe tener 8 caracteres";
        $tipo = "error";
    }
    else{
        $mesaje = "Registro exitoso";
        $tipo = "ok";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="4,1.css">
    <title>Validación</title>
</head>
<body>
    <div class="container">
        <h1>Validación</h1>
        <form action="" method="post">
            <input type="text" name="nombre" placeholder="Ingrese su nombre">
            <input type="text" name="email" placeholder="Ingrese su correo">
            <input type="password" name="password" placeholder="Ingrese su contraseña">
            <input type="number" name="edad" placeholder="Ingrese su edad">
            <button type="submit">Enviar</button>
        </form>
        <?php if($mesaje!=""):?>
            <div class="<?php echo $tipo;?>">
                <?php echo $mesaje;?>
            </div>
        <?php endif;?>
    </div>
</body>
</html>