<?php
$mensaje = "";
$tipo = "";
if($_POST){
    $user = $_POST['user'];
    $pass = $_POST['pass'];
    if($user == "admin" && $pass == "123"){

        $mensaje = "Bienvenido Administrador";
        $tipo = "ok";
    }
    elseif($user == "usuario" && $pass == "123"){
        $mensaje = "Bienvenido Usuario";
        $tipo = "ok";
    }
    elseif($user == "empleado" && $pass == "123"){

        $mensaje = "Bienvenido Empleado";
        $tipo = "ok";
    }
    else{
        $mensaje = "Datos incorrectos";
        $tipo = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=>, initial-scale=1.0">
    <link rel="stylesheet" href="4,2.css">
    <title>Incio de sesion</title>
</head>
<body>
    <div class="container">
        <h1>Inicio de sesion</h1>
        <form action="" method="post">
            <input type="text" name="user" placeholder="Ingrese su usuario">
            <input type="password" name="pass" placeholder="Ingrese su contraseña">
            <button type="submit">Enviar</button>
        </form>
        <?php if($mensaje!=""):?>
            <div class="<?php echo $tipo;?>">
                <?php echo $mensaje;?>
            </div>
        <?php endif;?>
</body>
</html>