<?php
$mensaje = "";
if($_POST){
    $password = $_POST['password'];
    if(strlen($password) < 8){
        $mensaje = "Minimo 8 caracteres";
    }
    elseif(!preg_match('/[A-Z]/', $password)){
        $mensaje = "Debe tener una mayuscula";
    }
    elseif(!preg_match('/[0-9]/', $password)){
        $mensaje = "Debe tener un numero";
    }
    else{
        $mensaje = "Contraseña fuerte";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="4,3.css">
    <title>Contraseñas seguras</title>
</head>
<body>
    <div class="container">
        <h1>Contraseñas seguras</h1>
        <form action="" method="post">
            <input type="password" name="password" placeholder="Ingrese su contraseña">
            <button type="submit">Enviar</button>
        </form>
        <?php if($mensaje!=""):?>
            <div class="alert alert-danger">
                <?php echo $mensaje;?>
            </div>
        <?php endif;?>
    </div>    
</body>
</html>