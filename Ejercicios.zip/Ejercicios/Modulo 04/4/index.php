<?php
$mesaje="";
$tipo="";
if($_POST){
    $nota=$_POST["nota"];
    if($nota>=18){
        $mesaje="Aprobado";
        $tipo="success";
    }
    elseif($nota>=12){
        $mesaje="Regular";
        $tipo="warning";
    }
    else{
        $mesaje="Desaprobado";
        $tipo="danger";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="4,3.css">
    <title>Notas</title>
</head>
<body>
    <div class="container">
        <h1>Notas</h1>
        <form action="" method="post">
            <input type="number" name="nota" placeholder="Ingrese su nota">
            <button type="submit">Enviar</button>
        </form>
        <?php if($mesaje!=""):?>
            <div class="alert alert-<?php echo $tipo;?>">
                <?php echo $mesaje;?>
            </div>
        <?php endif;?>
</body>
</html>