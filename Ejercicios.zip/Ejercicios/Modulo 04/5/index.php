<?php

$producto = "";
$precio = "";

if($_POST){

    $opcion = $_POST['producto'];

    switch($opcion){
        case "cuates":
            $producto = "Cuates";
            $precio = "S/ 1.5";
        break;
        case "cocacola":
            $producto = "Cocacola";
            $precio = "S/ 3.5";
        break;
        case "soda":
            $producto = "Soda V";
            $precio = "S/ 1.4";
        break;
        default:
            $producto = "Producto no encontrado";
            $precio = "";
        break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="4,5.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Productos</h1>
        <form action="" method="post">
            <select name="producto" id="">
                <option value="">Seleccione un producto</option>
                <option value="cuates">Cuates</option>
                <option value="cocacola">Cocacola</option>
                <option value="soda">Soda V</option>
            </select>
            <button type="submit">Enviar</button>
        </form>
        <?php if($producto!=""):?>
            <div class="alert alert-info">
                El producto es: <?php echo $producto;?> y su precio es: <?php echo $precio;?>
            </div>
        <?php endif;?>
</body>
</html>