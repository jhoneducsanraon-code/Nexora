<!-- EJERCICIO 1 -->
<?php
$productos = [
    ["nombre"=>"Laptop","precio"=>"850"],
    ["nombre"=>"Mouse","precio"=>"25"],
    ["nombre"=>"Teclado","precio"=>"40"],
    ["nombre"=>"Monitor","precio"=>"300"],
    ["nombre"=>"Audífonos","precio"=>"60"],
    ["nombre"=>"Celular","precio"=>"700"],
    ["nombre"=>"Tablet","precio"=>"450"],
    ["nombre"=>"Smartwatch","precio"=>"150"]
];
foreach($productos as $p){
    echo "
    <div>
    <h2>".$p['nombre']."</h2>
    <p>".$p['precio']."</p>
    <button>Comprar</button>
    </div>
    ";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="5,1.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Productos</h1>
        <form action="" method="post">
            <select name="producto" id="">
                <option value="">Seleccione un producto</option>
                <option value="cuates">Cuates</option>
                <option value="cocacola">Cocacola</option>
                <option value="soda">Soda V</option>
            </select>
            <button type="submit">Enviar</button>
        </form>
        <?php if($producto!=""):?>
            <div class="alert alert-info">
                El producto es: <?php echo $producto;?> y su precio es: <?php echo $precio;?>
            </div>
        <?php endif;?>
</body>
</html>