<?php

$empleados = [
    ["nombre"=>"Jhon","estado"=>"Activo"],
    ["nombre"=>"Carlos","estado"=>"Inactivo"]
];

foreach($empleados as $e){
$empleados[] = [] ;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Empleados</h1>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($empleados as $e):?>
                    <tr>
                        <td><?php echo $e['nombre'];?></td>
                        <td><?php echo $e['estado'];?></td>
                    </tr>
                <?php endforeach;?>
            </tbody>
        </table>
</body>
</html>