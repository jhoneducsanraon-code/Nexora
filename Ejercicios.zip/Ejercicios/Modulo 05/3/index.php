<?php
for($i=1;$i<=20;$i++){

    if($i % 2 == 0){
    $color = "Azul";
    }else{
    $color = "Morado";
    }

echo "
    <div>
    <h3>Tarjeta $i</h3>
    <p>Color: $color</p>
    </div>";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="5,3.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Tarjetas</h1>
        <?php
        for($i=1;$i<=20;$i++){

            if($i % 2 == 0){
            $color = "Azul";
            }else{
            $color = "Morado";
            }

        echo "
            <div>
            <h3>Tarjeta $i</h3>
            <p>Color: $color</p>
            </div>";

        }
        ?>
</body>
</html>