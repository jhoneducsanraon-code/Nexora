<?php

for($tabla=1; $tabla<=12; $tabla++){
    echo "<h2>Tabla del $tabla</h2>";
for($i=1; $i<=12; $i++){
$resultado = $tabla * $i;
    echo "$tabla x $i = $resultado <br>";
}
    echo "<hr>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=z, initial-scale=1.0">
    <link rel="stylesheet" href="5,4.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <h1>Tablas de Multiplicar</h1>
        <?php
        for($i= 1; $i<= 12; $i++){
            echo "";
        }
        ?>
    </div>
</body>
</html>